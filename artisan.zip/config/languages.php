<?php
return [
	'en' => ['English', 'en_US'],
	'es' => ['Spanish', 'es_ES'],
];