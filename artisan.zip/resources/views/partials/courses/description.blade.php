<div class="col-12 pt-0 mt-0">
    <h2 class="text-muted">{{ __("¿Qué vamos a hacer?") }}</h2>
    <hr />
</div>
<div class="col-12">
    <p class="mb-0">
        {{ $course->description }}
    </p>
</div>