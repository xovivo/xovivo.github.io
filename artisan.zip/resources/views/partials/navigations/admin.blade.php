<li><a class="nav-link" href="{{ route('admin.courses') }}">{{ __("Administrar cursos") }}</a></li>
<li><a class="nav-link" href="#">{{ __("Administrar estudiantes") }}</a></li>
<li><a class="nav-link" href="#">{{ __("Administrar profesores") }}</a></li>
@include('partials.navigations.logged')