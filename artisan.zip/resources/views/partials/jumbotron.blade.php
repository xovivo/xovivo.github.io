<div class="row">
    <div class="col-md-12">
        <div class="card pt-5" style="background-image: url('{{ url('/images/jumbotron.png') }}')">
            <h1 class="card-title pt-3 mb-5 text-center text-white">
                <i class="fa fa-{{ $icon }}"></i>
                <strong>{{ $title }}</strong>
            </h1>
        </div>
    </div>
</div>