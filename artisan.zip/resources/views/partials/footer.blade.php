<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm text-white text-center">
                {{ __(":app - Todos los derechos reservados", ['app' => env('APP_NAME')]) }}
            </div>
        </div>
    </div>
</footer>