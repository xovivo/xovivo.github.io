<form action="<?php echo e(route('courses.destroy', ['slug' => $course->slug])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger text-white">
        <i class="fa fa-trash"></i> <?php echo e(__("Eliminar curso")); ?>

    </button>
</form>