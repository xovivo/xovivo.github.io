<?php $__env->startSection('jumbotron'); ?>
    <?php echo $__env->make('partials.jumbotron', ['title' => 'Cursos que imparto', 'icon' => 'building'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pl-5 pr-5">
        <div class="row justify-content-center">
            <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-8 offset-2 listing-block">
                    <div class="media" style="height: 200px;">
                        <img
                            style="height: 200px; width: 300px;"
                            class="img-rounded"
                            src="<?php echo e($course->pathAttachment()); ?>"
                            alt="<?php echo e($course->name); ?>"
                        />

                        <div class="media-body pl-3" style="height: 200px">
                            <div class="price">
                                <small class="badge-danger text-white text-center">
                                    <?php echo e($course->category->name); ?>

                                </small>
                                <small><?php echo e(__("Curso")); ?>: <?php echo e($course->name); ?></small>
                                <small><?php echo e(__("Estudiantes")); ?>: <?php echo e($course->students_count); ?></small>
                            </div>

                            <div class="stats">
                                <?php echo e($course->created_at->format('d/m/Y')); ?>

                                <?php echo $__env->make('partials.courses.rating', ['rating' => $course->custom_rating], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>

                            <?php echo $__env->make('partials.courses.teacher_action_buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-dark">
                    <?php echo e(__("No tienes ningún curso todavía")); ?><br />
                    <a class="btn btn-course btn-block" href="<?php echo e(route('courses.create')); ?>">
                        <?php echo e(__("Crear mi primer curso!")); ?>

                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="row justify-content-center">
            <?php echo e($courses->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>