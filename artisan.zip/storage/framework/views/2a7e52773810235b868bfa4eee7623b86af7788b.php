<div class="col-12 pt-0 mt-0">
    <h2 class="text-muted"><?php echo e(__("Requisitos para tomar el curso")); ?></h2>
    <hr />
</div>
<?php $__empty_1 = true; $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-6">
        <div class="card bg-light p-3">
            <p class="mb-0">
                <?php echo e($requirement->requirement); ?>

            </p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-dark">
        <i class="fa fa-info-circle"></i>
        <?php echo e(__("No hay ningún requisito para este curso")); ?>

    </div>
<?php endif; ?>