<div class="row">
    <div class="col-md-12">
        <div class="card pt-5" style="background-image: url('<?php echo e(url('/images/jumbotron.png')); ?>')">
            <h1 class="card-title pt-3 mb-5 text-center text-white">
                <i class="fa fa-<?php echo e($icon); ?>"></i>
                <strong><?php echo e($title); ?></strong>
            </h1>
        </div>
    </div>
</div>